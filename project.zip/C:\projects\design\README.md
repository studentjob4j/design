design
[![Build Status](https://app.travis-ci.com/studentjob4j/design.svg?branch=master)](https://app.travis-ci.com/studentjob4j/design)
[![codecov](https://codecov.io/gh/studentjob4j/design/branch/master/graph/badge.svg?token=TIS85TC46E)](https://codecov.io/gh/studentjob4j/design)