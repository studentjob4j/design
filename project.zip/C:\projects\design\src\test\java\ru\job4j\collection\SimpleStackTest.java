package ru.job4j.collection;

import org.junit.Test;
import ru.job4j.collection.list.SimpleStack;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 * SimpleStack
 * @author Evgenii Shegai
 * @since 12.09.2021
 * @version 1.0
 */

public class SimpleStackTest {

    @Test
    public void whenPushThenPoll() {
        SimpleStack<Integer> stack = new SimpleStack<>();
        stack.push(1);
        assertThat(stack.pop(), is(1));
    }

    @Test
    public void whenPushPollThenPushPoll() {
        SimpleStack<Integer> stack = new SimpleStack<>();
        stack.push(1);
        stack.pop();
        stack.push(2);
        assertThat(stack.pop(), is(2));
    }

    @Test
    public void whenPushPushThenPollPoll() {
        SimpleStack<Integer> stack = new SimpleStack<>();
        stack.push(1);
        stack.push(2);
        stack.pop();
        assertThat(stack.pop(), is(1));
    }

}