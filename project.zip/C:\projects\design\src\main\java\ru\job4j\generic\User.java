package ru.job4j.generic;

/**
 * Универсальное хранилище Store
 * @author Evgenii Shegai
 * @since 08.09.2021
 * @version 1.0
 */

public class User extends Base {

    public User(String id) {
        super(id);
    }
}
