package ru.job4j.generic;

/**
 * Универсальное хранилище Store
 * @author Evgenii Shegai
 * @since 08.09.2021
 * @version 1.0
 */

public class Role extends Base {

    public Role(String id) {
        super(id);
    }
}
