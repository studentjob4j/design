package ru.job4j;

public class Trigger {

    public int summ(int a, int b) {
        return a + b;
    }
}
